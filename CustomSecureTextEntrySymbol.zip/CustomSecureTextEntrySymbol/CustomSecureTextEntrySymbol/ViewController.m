//
//  ViewController.m
//  CustomSecureTextEntrySymbol
//
//  Created by captain on 16/1/12.
//  Copyright © 2016年 codeIsMyGirl@163.com. All rights reserved.
//

#import "ViewController.h"
#import "SVProgressHUD.h"

// 暗文显示符
#define ShowSecureString @"💗"

@interface ViewController () <UITextFieldDelegate>

/// 判断是否存了数据
@property (nonatomic,assign) BOOL haveData;

/// 获取textField
@property (weak, nonatomic) IBOutlet UITextField *textField;

/// 以什么暗文显示
@property(nonatomic, copy) NSString *secureString;

///记录文本框里面输入的内容
@property(nonatomic, copy) NSString *contentString;


@end

@implementation ViewController

#warning 注意!!! 文本框中的数据是暗文,真数据在contentString里

#warning 注意!!! 文本框中的数据是暗文,真数据在contentString里

#warning 注意!!! 文本框中的数据是暗文,真数据在contentString里


- (IBAction)clickLogin:(id)sender {
    
    // 判断输入的是否正确
    if (![self.contentString isEqualToString:@"aa"]) {
        
        [SVProgressHUD showErrorWithStatus:@"请输入\"aa\"" maskType:SVProgressHUDMaskTypeBlack];
        
        return;
    }
    
    
    [SVProgressHUD showSuccessWithStatus:@"登陆成功" maskType:SVProgressHUDMaskTypeBlack];
        
        // 存档
    [self saveData];
 
    
}


- (void)loadContent {
    
    // 文本框 添加事件 (长度改变调用)
    [self.textField addTarget:self action:@selector(changeTextField) forControlEvents:UIControlEventEditingChanged];
    
    self.textField.delegate = self;
    
    //让控件成为第一响应者
    [self.textField becomeFirstResponder];
    
}

// 必须实现 屏蔽点击 键盘 return
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    //NSLog(@"%s",__func__);
    return NO;
}


#pragma mark - 因为用暗文替换,所以只有点X才调用此方法
- (void)changeTextField {
    

    self.textField.text = @"";
    
    self.contentString = @"";
    
}

#pragma mark -  自定义暗文显示符
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {

    // 屏蔽 用户输入键盘上的空格
    if ([string isEqualToString:@" "]) {
        
        return NO;
    }
    
    if (self.contentString  ==  nil) {
        
        self.contentString = @"";
    }
    
    //判断输入的 字符是否为 系统键盘的 delete 减号键
    if (string.length  == 0 ) {
        
        //去掉保存文本框的  最后一个字符
        self.contentString  = [self.contentString  substringToIndex:self.contentString.length - 1];
        
        //NSLog(@"%@",self.contentString);
        
        return YES;
    }
    
    //拼接字符串 保存的文本框内容加上一个字符
    self.contentString  = [self.contentString  stringByAppendingString:string];
    
    self.secureString = @"";
    
    /**
     *  遍历文本框内容长度  拼接安稳   字符串多长  拼接多长
     */
    for (int i = 0; i < self.contentString.length ; i ++) {
        
        self.secureString  = [self.secureString  stringByAppendingString:ShowSecureString];
        
    }
    
    self.textField.text  = self.secureString;
    
    return NO;
    
}


#pragma mark - 数据存储
- (void)saveData {
    
    //保存开关状态和用户信息
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    
    self.haveData = YES;
    
    //保存 BOOL 类型数据
    [userDefaults setBool:self.haveData forKey:@"haveData"];
    
    //保存 NSString 类型数据
    [userDefaults setObject:self.contentString forKey:@"contentString"];
    
    //立即写入 Ios8之前必须调用
    [userDefaults synchronize];
    
}

/// 读数据
- (void)loadData {
    
    //读取数据
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    
    self.haveData = [userDefaults
                     objectForKey:@"haveData"];
    
    if (self.haveData == NO) {
        
        // 代表没存数据
        return;
    }
    
    self.contentString = [userDefaults objectForKey:@"contentString"];
    
    self.textField.text  = ShowSecureString;
    
    // 把 密码文本框 替换
    for (int i = 0; i < self.contentString.length - 1; ++i) {
        
        self.textField.text = [self.textField.text stringByAppendingString:ShowSecureString];
        
    }
    
}


#pragma mark - 加载视图
- (void)loadView {
    
    [super loadView];
    
    // 设置整个控制器的背景图片
    self.view.layer.contents = (__bridge id _Nullable)([UIImage imageNamed:@"background"].CGImage);
    
    [self loadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    

    
    // 加载所有内容
    [self loadContent];
    
    
}


@end
