//
//  AppDelegate.h
//  CustomSecureTextEntrySymbol
//
//  Created by captain on 16/1/12.
//  Copyright © 2016年 codeIsMyGirl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

